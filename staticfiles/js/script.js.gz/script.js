var currentYear = new Date().getFullYear();

  document.getElementById("currentYear").textContent = currentYear;